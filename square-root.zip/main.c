#include <stdio.h>
#include<math.h>

int main()
{
    double a,b,c,r1,r2,D,real,imgpart;
    printf("Enter the coeffficients a,b,c ");
    scanf("%lf %lf %lf",&a,&b,&c);
    D=b*b - 4*a*c;
    if (D>0)
   {
    r1=(-b+sqrt(D))/(2*a);
    r2=(-b-sqrt(D))/(2*a);
    printf("Root 1=%.2lf Root 2=%.2lf",r1,r2);
   }
   else if (D==0)
   {
    r1=r2=-b/(2*a);
    printf("Root1=%.2lf Root2=%.2lf",r1,r2);
   }
   else
   {
    real=-b/(2*a);
    imgpart=sqrt(-D) / (2 * a);
    printf("Root1=%.2lf+%.2lfi Root2=%.2f-%.2fi",real,imgpart,real,imgpart);
   }
    return 0;
}
