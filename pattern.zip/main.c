#include <stdio.h>

int main()
{   int i,j,k=1,ch;
    printf("Enter an option ");
    scanf("%d",&ch);
    switch(ch)
    {case 1:
    i=1;j=1;
    for(i=1;i<=10;i++)
    {
    for(j=1;j<=i;j++)
    {
    printf("#");
    }
    printf("\n");
    }
    break;
    case 2:
    for(i=1;i<=10;i++)
    {
    for(j=10;j>=i;j--)
    {
    printf("@");
    }
    printf("\n");
    }
    break;
    case 3:
    for(i=1;i<=7;i++)
    {
    for(j=1;j<=i;j++)
    {
    printf("%c",i+64);
    }
    printf("\n");
    }
    break;
    case 4:
    for(i=1;i<=5;i++)
    {
    for(j=1;j<=i;j++)
    {
    printf("%d\t",k);
    k++;
    }
    printf("\n");
    }
    break;
    }
    return 0;
}



