#include <stdio.h>

int main()
{   int a,b,c,GCD;
    printf("Enter a Number-1 ");
    scanf("%d",&a);
    printf("Enter a Number-2 ");
    scanf("%d",&b);
    for(c=1;c<=a&&c<=b;c++)
    {
    if(a%c==0&&b%c==0)
    GCD=c;
    }
    printf("%d is the Greatest Common Divisor of %d and %d",GCD,a,b);
    return 0;
}
