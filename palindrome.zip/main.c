#include<stdio.h>  
int main()    
{    
int n,r,sum=0,k;    
printf("Enter the number=");    
scanf("%d",&n);    
k=n;    
while(n>0)    
{    
r=n%10;    
sum=(sum*10)+r;    
n=n/10;    
}    
if(k==sum)    
printf("It's a Palindrome number ");    
else    
printf("Not a palindrome number");   
return 0;  
}   
