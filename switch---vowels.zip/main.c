#include <stdio.h>

int main()
{ char ch;
    printf("Enter a letter ");
    scanf("%c",&ch);
    switch(ch)
    {
    case 'a':
    printf("Its a vowel");
    break;
    case 'e':
    printf("Its a vowel");
    break; 
    case 'i':
    printf("Its a vowel");
    break; 
    case 'o':
    printf("Its a vowel");
    break; 
    case 'u':
    printf("Its a vowel");
    break;
    default:
    printf("Its a consonant");
    }
    return 0;
}
