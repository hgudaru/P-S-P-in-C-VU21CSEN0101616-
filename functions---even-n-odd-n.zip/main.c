#include <stdio.h>
void even();
void odd();
void main()
{
    even();
    odd();

}
void even()
{
    int a,b;
    printf("Enter the range[a,b] ");
    scanf("%d %d",&a,&b);
    printf("even numbers\n");
    for(a;a<=b;a++)
    printf("%d\n",++a);
   
}
void odd()
{   
    int a,b;
    printf("Enter the range[a,b] ");
    scanf("%d %d",&a,&b);
    printf("odd numbers\n");
    for(a;a<=b;++a)
    printf("%d\n",a++);
}